package com.softuni.residentevil.services;

public interface Creatable {

    boolean create(final Object dto);
}
