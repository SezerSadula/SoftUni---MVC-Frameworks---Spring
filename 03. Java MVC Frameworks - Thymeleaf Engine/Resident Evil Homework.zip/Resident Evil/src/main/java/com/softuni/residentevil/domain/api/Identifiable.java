package com.softuni.residentevil.domain.api;

public interface Identifiable<T> {
    T getId();
}
