package org.softuni.eventures;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventuresApplication {
    public static void main(String[] args) {
        SpringApplication.run(EventuresApplication.class, args);
    }
}
