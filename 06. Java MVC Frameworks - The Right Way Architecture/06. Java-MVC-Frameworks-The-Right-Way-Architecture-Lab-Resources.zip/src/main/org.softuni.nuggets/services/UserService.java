package org.softuni.nuggets.services;

import org.softuni.nuggets.models.binding.RegisterUserBindingModel;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface UserService extends UserDetailsService {
    void register(RegisterUserBindingModel bindingModel);

    void addPreferences(String username, List<String> preferences);
}
