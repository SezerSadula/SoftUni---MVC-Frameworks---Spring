package org.softuni.nuggets.models.view;

public class NuggetViewModel {
    private String name;

    public NuggetViewModel() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
