package org.softuni.residentevil.entities.enums;

public enum UserRole {
    USER,
    ADMIN
}
